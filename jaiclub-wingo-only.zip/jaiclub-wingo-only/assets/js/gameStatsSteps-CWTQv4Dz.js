const s="/assets/png/gameStatsSteps-2Xef43OK.png";export{s as _};
