#!/usr/bin/env python3
"""WinGo page ki missing files original site se utarta hai (aur unki dependencies bhi, khud dhundh kar).
Chalao (is folder ke andar):  python fetch_missing.py
Sirf check karna ho:          python fetch_missing.py --dry
"""
import os, re, sys, urllib.request, urllib.error

BASE = "https://www.jaiclub04.com"
UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
DRY = "--dry" in sys.argv

SEED = """assets/js/index-DXGt56IM.js
assets/js/audio-J-1i6LBI.js
assets/css/audio-BLqQieiv.css
assets/js/WinningTips-DpNeAmLO.js
assets/css/WinningTips-cOBmMT4b.css
assets/js/MyGameRecord-Cinb1eWp.js
assets/js/MayrecordList-E-8MN-ZE.js
assets/css/MayrecordList-Dx2jSFCJ.css
assets/css/MyGameRecord-2WiBGp3K.css
assets/css/index-Du2XNdzz.css""".split()

RX = [
  (re.compile(r'["\'`]\./([\w\-.]+\.js)["\'`]'), "assets/js/"),           # import "./x.js"
  (re.compile(r'["\'`]\.\./(css|png|svg|mp3|json|woff2|jpg|jpeg|webp|gif)/([\w\-.]+)["\'`]'), "assets/{0}/{1}"),
  (re.compile(r'assets/(js|css|png|svg|mp3|json|woff2|jpg|webp)/([\w\-.]+\.\w+)'), "assets/{0}/{1}"),
  (re.compile(r'url\(["\']?\.\./(png|svg|woff2|jpg|webp|gif)/([\w\-.]+)["\']?\)'), "assets/{0}/{1}"),
]

def refs(text):
    out = set()
    for rx, fmt in RX:
        for m in rx.finditer(text):
            g = m.groups()
            out.add(fmt + g[0] if len(g) == 1 else fmt.format(*g))
    return out

def get(path):
    req = urllib.request.Request(BASE + "/" + path, headers={"User-Agent": UA, "Referer": BASE + "/"})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read()
        ctype = r.headers.get("Content-Type", "")
    if path.endswith(".js") and b"<html" in data[:300].lower():
        raise ValueError("JS ki jagah HTML mila (site ne block kiya ya file nahi hai)")
    return data

queue, seen, ok, fail = list(SEED), set(), [], []
while queue:
    p = queue.pop(0)
    if p in seen: continue
    seen.add(p)
    if os.path.exists(p):
        if p.endswith((".js", ".css")) and p in SEED:
            pass
        else:
            continue
    if DRY:
        print("chahiye:", p); continue
    try:
        data = get(p)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        open(p, "wb").write(data)
        ok.append(p); print("ok  ", p)
        if p.endswith((".js", ".css")):
            for r in refs(data.decode("utf-8", "ignore")):
                if r not in seen and not os.path.exists(r): queue.append(r)
    except (urllib.error.URLError, ValueError, OSError) as e:
        fail.append(p); print("FAIL", p, "->", e)

print("\nDone. mila:", len(ok), "| nahi mila:", len(fail))
if fail: print("Jo FAIL hue wo mujhe bhej do.")
